# Contrubution

## Intro

You need to have knowledge of Npm and Git.

* Install NodeJs

* Install Git

* Fork SunDrop

* clone Your Fork

      git clone https://github.com/[yourgithubname]/SunDrop.git

## Making changes

When you’ve decided to make changes, start with the following:

* Update your local repo

      git pull https://github.com/GappleCider/Sundrop.git
      git push

* Make a new branch from the dev branch

      git checkout dev
      git branch [mychangesbranch]
      git checkout [mychangesbranch]

* Add your changes to your commit.
* Push the changes to your forked repo.
* Open a Pull Request (PR)
